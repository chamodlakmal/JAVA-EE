package com.im.myebay.model;

public class Member {

}
